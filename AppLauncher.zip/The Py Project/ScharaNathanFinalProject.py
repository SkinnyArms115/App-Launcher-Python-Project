import tkinter as tk
from tkinter import filedialog, Text, PhotoImage
import os

root = tk.Tk()
apps = []

root.title('App Launcher')

if os.path.isfile('save.txt'):
    with open('save.txt', 'r') as f:
        tempApps = f.read()
        tempApps = tempApps.split(',')
        apps = [x for x in tempApps if x.strip()]


def addApp():
    for widget in frame.winfo_children():
        widget.destroy()

    filename = filedialog.askopenfilename(initialdir="/", title="Select File",
                                          filetypes=(("executables", "*.exe"), ("all files", "*.*")))
    apps.append(filename)
    print(filename)
    for app in apps:
        label = tk.Label(frame, text=app, bg="gray")
        label.pack()


def runApps():
    for app in apps:
        os.startfile(app)


canvas = tk.Canvas(root, height=820, width=700, bg="#263D42")
canvas.pack()

my_image = PhotoImage(file='images\\logo.png')
canvas.create_image(350, 40, image=my_image)

my_image2 = PhotoImage(file='images\\glow.png')
canvas.create_image(36, 450, image=my_image2)

my_image3 = PhotoImage(file='images\\glow.png')
canvas.create_image(670, 450, image=my_image3)

frame = tk.Frame(root, bg="black")
frame.place(relwidth=0.8, relheight=0.8, relx=0.1, rely=0.1)

openFile = tk.Button(root, text="Open File", padx=10, pady=5, fg="white", bg="#263D42", command=addApp)
openFile.pack()

runApps = tk.Button(root, text="Run apps", padx=10, pady=5, fg="white", bg="#263D42", command=runApps)
runApps.pack()

label1 = tk.Label(root, text="To clear apps delete save.txt", bg="white")
label1.pack()

for app in apps:
    label = tk.Label(frame, text=app)
    label.pack()

root.mainloop()

with open('save.txt', 'w') as f:
    for app in apps:
        f.write(app + ',')
